const API_URL = "http://127.0.0.1:8080"; // URL da API Quarkus

// Funções para chamar a API
async function fetchAnimais() {
    try {
        const response = await fetch(`${API_URL}/animais`);
        if (!response.ok) throw new Error("Falha ao buscar animais");
        return await response.json();
    } catch (error) {
        console.error("Erro ao buscar animais:", error);
        alert("Erro ao carregar animais: " + error.message);
        return [];
    }
}

async function fetchPesagens(animalId = null, limit = null) {
    try {
        let url = `${API_URL}/pesagens`;
        if (animalId) url += `?tagRFID=${animalId}`;
        if (limit) url += `${animalId ? '&' : '?'}limit=${limit}`;

        const response = await fetch(url);
        if (!response.ok) throw new Error("Falha ao buscar pesagens");
        return await response.json();
    } catch (error) {
        console.error("Erro ao buscar pesagens:", error);
        alert("Error ao carregar pesagens: " + error.message);
        return [];
    }
}

async function registrarPesagemAPI(tagRFID, peso) {
    const response = await fetch(`${API_URL}/pesagens`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tagRFID, peso })
    });
    return await response.json();
}

// Elementos da página
const conteudoPrincipal = document.getElementById("conteudo-principal");
const totalAnimaisElement = document.getElementById("total-animais");
const ultimaPesagemElement = document.getElementById("ultima-pesagem");

// Atualizar dashboard
async function atualizarDashboard() {
    const animais = await fetchAnimais();
    const pesagens = await fetchPesagens(null, 1); // Última pesagem

    totalAnimaisElement.textContent = animais.length;

    if (pesagens.length > 0) {
        const animal = animais.find(a => a.tagRFID === pesagens[0].tagRFID);
        ultimaPesagemElement.textContent =
            `${animal.nome} : ${pesagens[0].peso} kg em ${new Date(pesagens[0].data).toLocaleDateString()}`;
    }
    renderizarGrafico();
}

// Renderizar gráfico de evolução de peso
async function renderizarGrafico() {
    const ctx = document.getElementById('peso-chart').getContext('2d');
    const animais = await fetchAnimais();
    const pesagens = await fetchPesagens();

    const dadosPorAnimal = {};
    animais.forEach(animal => {
        dadosPorAnimal[animal.tagRFID] = {
            nome: animal.nome,
            dados: pesagens
                .filter(p => p.tagRFID === animal.tagRFID)
                .sort((a, b) => new Date(a.data) - new Date(b.data))
                .map(p => ({
                    x: new Date(p.data),
                    y: p.peso
                }))
        };
    });
    
    const datasets = Object.values(dadosPorAnimal).map(animal => ({
        label: animal.nome,
        data: animal.dados,
        borderColor: `#${Math.floor(Math.random()*16777215).toString(16)}`,
        tension: 0.1,
        fill: false
    }));
    
    new Chart(ctx, {
        type: 'line',
        data: { datasets },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'day'
                    }
                },
                y: {
                    beginAtZero: false
                }
            }
        }
    });
}

// Atualizar Animal
async function atualizarAnimal(tagRFID, dadosAtualizados) {
    try {
        const response = await fetch(`${API_URL}/animais/${tagRFID}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dadosAtualizados)
        });
        return await response.json();
    } catch (error) {
        console.error("Erro ao atualizar animal:", error);
    }
}

// Deletar Animal
async function deletarAnimal(tagRFID) {
    try {
        const response = await fetch(`${API_URL}/animais/${tagRFID}`, {
            method: "DELETE"
        });
        return response.status === 204;
    } catch (error) {
        console.error("Erro ao deletar animal:", error);
    }
}

// Atualizar Pesagem
async function atualizarPesagem(id, novosDados) {
    try {
        const response = await fetch(`${API_URL}/pesagens/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(novosDados)
        });
        return await response.json();
    } catch (error) {
        console.error("Erro ao atualizar pesagem:", error);
    }
}

// Deletar Pesagem
async function deletarPesagem(id) {
    try {
        const response = await fetch(`${API_URL}/pesagens/${id}`, {
            method: "DELETE"
        });
        return response.status === 204;
    } catch (error) {
        console.error("Erro ao deletar pesagem:", error);
    }
}

// Funções de apoio:
async function editarPesagem(id, pesoAtual) {
    const novoPeso = prompt("Novo peso:", pesoAtual);
    if (novoPeso) {
        await atualizarPesagem(id, { peso: parseFloat(novoPeso) });
        atualizarHistorico();
    }
}

async function confirmarExclusaoPesagem(id) {
    if (confirm("Deseja realmente excluir esta pesagem?")) {
        await deletarPesagem(id);
        atualizarHistorico();
    }
}

// Navegação entre páginas
document.getElementById("inicio-link").addEventListener("click", (e) => {
    e.preventDefault();
    conteudoPrincipal.innerHTML = `
        <section class="dashboard">
            <h2><i class="fas fa-tachometer-alt icon"></i>Dashboard</h2>
            <div class="cards-container">
                <div class="card">
                    <h3><i class="fas fa-cow icon"></i>Total de Animais</h3>
                    <p id="total-animais">0</p>
                </div>
                <div class="card">
                    <h3><i class="fas fa-weight-hanging icon"></i>Última Pesagem</h3>
                    <p id="ultima-pesagem">Nenhuma pesagem registrada</p>
                </div>
            </div>
            <div class="grafico-container">
                <canvas id="peso-chart"></canvas>
            </div>
        </section>
    `;
    atualizarDashboard();
});

document.getElementById("pesagem-link").addEventListener("click", (e) => {
    e.preventDefault();
    conteudoPrincipal.innerHTML = `
        <section class="pesagem">
            <h2><i class="fas fa-weight-hanging icon"></i>Pesagem em Tempo Real</h2>
            <div id="pesagem-atual">
                <p>Aguardando pesagem...</p>
            </div>
            <h3>Últimas Pesagens</h3>
            <table>
                <thead>
                    <tr>
                        <th>Animal</th>
                        <th>Peso (kg)</th>
                        <th>Data/Hora</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="tabela-pesagens">
                    <!-- Preenchido por JavaScript -->
                </tbody>
            </table>
        </section>
    `;

    // Função para atualizar a pesagem em tempo real
    async function atualizarPesagemTempoReal() {
        const [pesagens, animais] = await Promise.all([
            fetchPesagens(null, 1), // Busca a pesagem mais recente
            fetchAnimais()
        ]);
    
        const pesagemAtualDiv = document.getElementById("pesagem-atual");
        if (pesagens.length > 0) {
            const pesagem = pesagens[0];
            const animal = animais.find(a => a.tagRFID === pesagem.tagRFID);
            pesagemAtualDiv.innerHTML = `
                <p><strong>Animal:</strong> ${animal ? animal.nome : 'Desconhecido'}</p>
                <p><strong>Peso:</strong> ${pesagem.peso} kg</p>
                <p><strong>Data/Hora:</strong> ${new Date(pesagem.data).toLocaleString()}</p>
            `;
            // Mostrar notificação
            const notification = document.createElement("div");
            notification.className = "notification"; // Usa a classe 'notification' do CSS
            notification.textContent = `Nova pesagem registrada: ${animal ? animal.nome : 'Desconhecido'} - ${pesagem.peso} kg`;
            document.body.appendChild(notification);
            setTimeout(() => notification.remove(), 3000);
        } else {
            pesagemAtualDiv.innerHTML = `<p>Aguardando pesagem...</p>`;
        }
    
        atualizarTabelaPesagens();
    }

    // Atualiza a cada 5 segundos
    atualizarPesagemTempoReal();
    const intervalId = setInterval(atualizarPesagemTempoReal, 5000);

    // Limpa o intervalo quando o usuário sair da página
    conteudoPrincipal.addEventListener('remove', () => clearInterval(intervalId), { once: true });
    
    // Simular conexão com a balança (substituir por WebSocket/API real)
    setInterval(() => {
        // Em produção, isso seria substituído por uma conexão real com a balança
    }, 5000);
    
    atualizarTabelaPesagens();
});

document.getElementById("historico-link").addEventListener("click", async (e) => {
    e.preventDefault();
    const animais = await fetchAnimais();

    conteudoPrincipal.innerHTML = `
        <section class="historico">
            <h2>Histórico de Pesagens</h2>
            <div class="filtros">
                <select id="filtro-animal">
                    <option value="">Todos os animais</option>
                    ${animais.map(a => `<option value="${a.tagRFID}">${a.nome}</option>`).join('')}
                </select>
                <input type="date" id="filtro-data">
                <button id="aplicar-filtros">Aplicar Filtros</button>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Animal</th>
                        <th>Peso (kg)</th>
                        <th>Data/Hora</th>
                    </tr>
                </thead>
                <tbody id="tabela-historico">
                    <!-- Preenchido por JavaScript -->
                </tbody>
            </table>
        </section>
    `;
    
    document.getElementById("aplicar-filtros").addEventListener("click", atualizarHistorico);
    atualizarHistorico();
});
    
document.getElementById("cadastro-link").addEventListener("click", function (e) {
    e.preventDefault();
    conteudoPrincipal.innerHTML = `
        <section class="form-cadastro">
            <h2><i class="fas fa-paw icon"></i> Cadastrar Novo Animal</h2>
            <form id="form-animal">
                <div class="form-group">
                    <label for="tagRFID">Tag RFID:</label>
                    <input type="text" id="tagRFID" required>
                </div>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" required>
                </div>
                <div class="form-group">
                    <label for="raca">Raça:</label>
                    <input type="text" id="raca" required>
                </div>
                <div class="form-group">
                    <label for="data-nascimento">Data de Nascimento:</label>
                    <input type="date" id="data-nascimento" required>
                </div>
                <button type="submit"><i class="fas fa-save icon"></i> Cadastrar Animal</button>
            </form>
        </section>
    `;

    document.getElementById("form-animal").addEventListener("submit", async function (e) {
        e.preventDefault();
        const tagRFID = document.getElementById("tagRFID").value.trim();
        const nome = document.getElementById("nome").value.trim();
        const raca = document.getElementById("raca").value.trim();
        const dataNascimento = document.getElementById("data-nascimento").value;

        // Validações
        if (!tagRFID.match(/^[0-9A-Fa-f]{14}$/)) {
            alert("Tag RFID deve ter 14 caracteres hexadecimais!");
            return;
        }
        if (nome.length < 2) {
            alert("Nome deve ter pelo menos 2 caracteres!");
            return;
        }
        if (raca.length < 2) {
            alert("Raça deve ter pelo menos 2 caracteres!");
            return;
        }
        if (!dataNascimento) {
            alert("Data de nascimento é obrigatória!");
            return;
        }
        const dataNasc = new Date(dataNascimento);
        if (dataNasc > new Date()) {
            alert("Data de nascimento não pode ser no futuro!");
            return;
        }

        try {
            const response = await fetch(`${API_URL}/animais`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    tagRFID,
                    nome,
                    raca,
                    dataNascimento
                })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || "Falha ao cadastrar animal");
            }
            alert("Animal cadastrado com sucesso!");
            document.getElementById("inicio-link").click();
        } catch (error) {
            alert("Erro: " + error.message);
        }
    });
});

async function atualizarTabelaPesagens() {
    const [pesagens, animais] = await Promise.all([
        fetchPesagens(null, 5),
        fetchAnimais()
    ]);

    const tbody = document.getElementById("tabela-pesagens");
    tbody.innerHTML = pesagens
        .map(p => {
            const animal = animais.find(a => a.tagRFID === p.tagRFID);
            return `
                <tr>
                    <td>${animal.nome}</td>
                    <td>${p.peso} kg</td>
                    <td>${new Date(p.data).toLocaleString()}</td>
                    <td class="acoes">
                        <button onclick="editarPesagem(${p.id}, ${p.peso})" class="btn-editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="confirmarExclusaoPesagem(${p.id})" class="btn-excluir">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        })
        .join('');
}

async function atualizarHistorico() {
    const animalId = document.getElementById("filtro-animal").value;
    const dataFiltro = document.getElementById("filtro-data").value;
    
    const [pesagens, animais] = await Promise.all([
        fetchPesagens(),
        fetchAnimais()
    ]);

    let pesagensFiltradas = [...pesagens];
    
    if (animalId) {
        pesagensFiltradas = pesagensFiltradas.filter(p => p.tagRFID === animalId);
    }
    
    if (dataFiltro) {
        const data = new Date(dataFiltro);
        pesagensFiltradas = pesagensFiltradas.filter(p => {
            const pesagemDate = new Date(p.data);
            return pesagemDate.toDateString() === data.toDateString();
        });
    }
    
    const tbody = document.getElementById("tabela-historico");
    tbody.innerHTML = pesagensFiltradas
        .map(p => {
            const animal = animais.find(a => a.tagRFID === p.tagRFID);
            return `
                <tr>
                    <td>${animal.nome}</td>
                    <td>${p.peso} kg</td>
                    <td>${new Date(p.data).toLocaleString()}</td>
                    <td class="acoes">
                        <button onclick="editarPesagem(${p.id}, ${p.peso})" class="btn-editar">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="confirmarExclusaoPesagem(${p.id})" class="btn-excluir">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        })
        .join('');
}

       
document.getElementById("contato-link").addEventListener("click", (e) => {
    e.preventDefault();
    conteudoPrincipal.innerHTML = `
        <section class="contato">
            <h2><i class="fas fa-envelope icon"></i> Contato</h2>
            <div class="card">
                <h3>Entre em contato conosco</h3>
                <p><i class="fas fa-phone icon"></i> (63) 99999-9999</p>
                <p><i class="fas fa-envelope icon"></i> contato@balancainteligente.com.br</p>
                <p><i class="fas fa-map-marker-alt icon"></i> Agrotins - Palmas/TO</p>
            </div>
        </section>
    `;
});

// Inicializar a página
document.getElementById("inicio-link").click();